# 寮犺禌瀵掕壓鏈涓汉缃戠珯 | Sihan Zhang Artist Website

杩欐槸涓€涓负鑹烘湳瀹跺紶璧涘瘨 (Sihan Zhang) 鍒涘缓鐨勪釜浜轰綔鍝侀泦缃戠珯銆?
This is a personal portfolio website created for artist Sihan Zhang.

## 馃搧 鏂囦欢缁撴瀯

```
artist-website/
鈹溾攢鈹€ index.html      # 涓婚〉闈?鈹溾攢鈹€ styles.css      # 鏍峰紡鏂囦欢
鈹溾攢鈹€ script.js       # 浜や簰鑴氭湰
鈹斺攢鈹€ README.md       # 璇存槑鏂囨。
```

## 馃殌 浣跨敤鏂规硶

### 鏈湴棰勮

鐩存帴鍦ㄦ祻瑙堝櫒涓墦寮€ `index.html` 鏂囦欢鍗冲彲棰勮缃戠珯锛?
```bash
# Windows
start index.html

# 鎴栦娇鐢?Python 鍚姩鏈湴鏈嶅姟鍣?python -m http.server 8000
# 鐒跺悗璁块棶 http://localhost:8000
```

### 閮ㄧ讲鍒扮綉缁?
#### 閫夐」 1: GitHub Pages (鎺ㄨ崘)
1. 灏嗘枃浠朵笂浼犲埌 GitHub 浠撳簱
2. 鍦ㄤ粨搴撹缃腑鍚敤 GitHub Pages
3. 璁块棶 `https://yourusername.github.io/repo-name`

#### 閫夐」 2: Netlify
1. 璁块棶 [Netlify](https://netlify.com)
2. 鎷栨嫿 `artist-website` 鏂囦欢澶瑰埌閮ㄧ讲鍖哄煙
3. 鑾峰緱鍏嶈垂鐨?HTTPS 缃戝潃

#### 閫夐」 3: Vercel
1. 璁块棶 [Vercel](https://vercel.com)
2. 瀵煎叆 GitHub 浠撳簱鎴栫洿鎺ヤ笂浼犳枃浠?3. 鑷姩閮ㄧ讲骞惰幏寰楃綉鍧€

## 馃帹 缃戠珯鐗圭偣

- **鍝嶅簲寮忚璁?*: 瀹岀編閫傞厤妗岄潰銆佸钩鏉垮拰鎵嬫満
- **鐜颁唬绠€绾﹂鏍?*: 绐佸嚭鑹烘湳浣滃搧鏈韩
- **娴佺晠鍔ㄧ敾**: 婊氬姩瑙嗗樊鍜屾贰鍏ユ晥鏋?- **鏃堕棿绾垮睍绀?*: 娓呮櫚鍛堢幇灞曡缁忓巻
- **鑱旂郴淇℃伅**: 鏂逛究钘忓鍜岀瓥灞曚汉鑱旂郴

## 馃摑 鍐呭璇存槑

缃戠珯鍖呭惈浠ヤ笅鏉垮潡锛?
1. **棣栭〉**: 鑹烘湳瀹跺鍚嶃€佷綅缃拰鍒涗綔鐞嗗康
2. **鍏充簬**: 鑹烘湳瀹剁畝浠嬪拰椹诲湴缁忓巻
3. **浣滃搧**: 浜斾釜涓昏浣滃搧绯诲垪灞曠ず
   - 瑙傚療鑰?(2025)
   - 杈圭晫 (2022)
   - 鎯呯华 (2019-2020)
   - 娼滄剰璇?(2014)
   - 椹?(2012-2013)
4. **灞曡**: 瀹屾暣鐨勫睍瑙堟椂闂寸嚎
5. **鑱旂郴**: 鐢佃瘽銆侀偖绠便€佸井淇?
## 馃柤锔?浣滃搧鍥剧墖

缃戠珯宸查厤缃ソ鍥剧墖鏄剧ず銆?*璇峰皢鎮ㄧ殑浣滃搧鐓х墖娣诲姞鍒?`images/` 鏂囦欢澶?*锛?
### 浣滃搧鍥剧墖

| 鏂囦欢鍚?| 浣滃搧鍚嶇О | 骞翠唤 |
|--------|----------|------|
| `observer-2025.jpg` | 瑙傚療鑰?| 2025 |
| `boundary-2022.jpg` | 杈圭晫绯诲垪 | 2022 |
| `emotions-2019.jpg` | 鎯呯华绯诲垪 | 2019-2020 |
| `subconscious-2014.jpg` | 娼滄剰璇嗙郴鍒?| 2014 |
| `horse-2012.jpg` | 椹郴鍒?| 2013 |

### 鑳屾櫙鍥剧墖

| 鏂囦欢鍚?| 鐢ㄩ€?|
|--------|------|
| `hero-bg.jpg` | 棣栭〉澶ц儗鏅紙鎺ㄨ崘鏈€鍏蜂唬琛ㄦ€х殑浣滃搧锛?|
| `about-bg.jpg` | 鍏充簬椤甸潰鑳屾櫙 |
| `exhibitions-bg.jpg` | 灞曡椤甸潰鑳屾櫙 |
| `work-placeholder-bg.jpg` | 浣滃搧鍗＄墖榛樿鑳屾櫙 |

馃摉 **璇︾粏璇存槑**: 鏌ョ湅 `images/README.md` 鑾峰彇鍥剧墖瑕佹眰鍜屾坊鍔犳寚鍗椼€?
> 馃挕 濡傛灉鍥剧墖鏈坊鍔狅紝缃戠珯浼氫娇鐢ㄩ粯璁ゆ笎鍙樿壊鑳屾櫙锛屼笉褰卞搷娴忚銆?
## 馃摓 鑱旂郴淇℃伅 | Contact

- **閭 | Email**: saihan77@qq.com
- **寰俊 | WeChat**: shaunwhite17
- **Instagram**: @saihsaihsaih

## 馃搫 璁稿彲璇?| License

漏 2025 寮犺禌瀵?Sihan Zhang. All Rights Reserved.

---

*缃戠珯鍒涘缓浜?2025 骞?3 鏈?| Website created in March 2025*
