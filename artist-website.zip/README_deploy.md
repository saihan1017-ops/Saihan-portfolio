﻿# 缃戠珯閮ㄧ讲鎸囧崡 馃殌

## 璁╃綉绔欏湪鍏ㄧ悆閮借兘璁块棶

---

## 鏂规涓€锛欸itHub Pages锛堝厤璐癸紝鎺ㄨ崘锛夆瓙

### 姝ラ锛?
1. **瀹夎 Git**
   - 涓嬭浇鍦板潃锛歨ttps://git-scm.com/download/win
   - 瀹夎鍚庨噸鍚粓绔?
2. **鍒涘缓 GitHub 璐﹀彿**
   - 璁块棶锛歨ttps://github.com
   - 娉ㄥ唽鍏嶈垂璐﹀彿

3. **鍒涘缓浠撳簱**
   - 鐧诲綍 GitHub
   - 鐐瑰嚮鍙充笂瑙?"+" 鈫?"New repository"
   - 浠撳簱鍚嶏細`sihanzhang-art`锛堟垨浣犲枩娆㈢殑鍚嶅瓧锛?   - 閫夋嫨 "Public"
   - 鐐瑰嚮 "Create repository"

4. **涓婁紶缃戠珯鏂囦欢**
   ```bash
   # 鍦?website 鏂囦欢澶规墦寮€缁堢
   cd C:\Users\huawei\.easyclaw\workspace\artist-website
   
   # 鍒濆鍖?git
   git init
   git add .
   git commit -m "Initial commit"
   
   # 鍏宠仈 GitHub 浠撳簱锛堟浛鎹负浣犵殑浠撳簱鍦板潃锛?   git remote add origin https://github.com/浣犵殑鐢ㄦ埛鍚?sihanzhang-art.git
   git branch -M main
   git push -u origin main
   ```

5. **鍚敤 GitHub Pages**
   - 杩涘叆浠撳簱 鈫?Settings 鈫?Pages
   - Source 閫夋嫨 "main" 鍒嗘敮
   - 鐐瑰嚮 Save
   - 绛夊緟鍑犲垎閽燂紝缃戠珯灏变細鍙戝竷

6. **璁块棶鍦板潃**
   - `https://浣犵殑鐢ㄦ埛鍚?github.io/sihanzhang-art/`

---

## 鏂规浜岋細Vercel锛堝厤璐癸紝鏇村揩锛夆瓙猸?
### 姝ラ锛?
1. **璁块棶 Vercel**
   - https://vercel.com
   - 鐢?GitHub 璐﹀彿鐧诲綍

2. **瀵煎叆椤圭洰**
   - 鐐瑰嚮 "Add New Project"
   - 閫夋嫨浣犵殑 GitHub 浠撳簱
   - 鐐瑰嚮 "Deploy"

3. **璁块棶鍦板潃**
   - `https://sihanzhang-art.vercel.app/`

---

## 鏂规涓夛細Netlify锛堝厤璐癸紝绠€鍗曟嫋鎷斤級猸愨瓙

### 姝ラ锛?
1. **璁块棶 Netlify**
   - https://www.netlify.com
   - 娉ㄥ唽璐﹀彿

2. **鎷栨嫿閮ㄧ讲**
   - 鐧诲綍鍚庣殑 Dashboard
   - 鐩存帴鎶?`artist-website` 鏂囦欢澶规嫋鍒伴儴缃插尯鍩?   - 绛夊緟涓婁紶瀹屾垚

3. **璁块棶鍦板潃**
   - `https://闅忔満鍚嶅瓧.netlify.app/`
   - 鍙互鍦?Site settings 鈫?Change site name 鑷畾涔?
---

## 鏂规鍥涳細Cloudflare Pages锛堝厤璐癸紝閫熷害蹇級猸愨瓙猸?
### 姝ラ锛?
1. **璁块棶 Cloudflare**
   - https://pages.cloudflare.com
   - 娉ㄥ唽璐﹀彿

2. **杩炴帴 GitHub**
   - 閫夋嫨浣犵殑浠撳簱
   - 鐐瑰嚮 "Begin setup"
   - 鐐瑰嚮 "Save and Deploy"

3. **璁块棶鍦板潃**
   - `https://sihanzhang-art.pages.dev/`

---

## 馃實 鑷畾涔夊煙鍚嶏紙鍙€夛級

濡傛灉鎯崇敤鑷畾涔夊煙鍚嶏紙濡?`www.sihanzhang.com`锛夛細

1. **璐拱鍩熷悕**
   - Namecheap: https://www.namecheap.com
   - GoDaddy: https://www.godaddy.com
   - 浠锋牸锛氱害 $10-15/骞?
2. **缁戝畾鍒版墭绠″钩鍙?*
   - 鍦ㄥ钩鍙拌缃腑娣诲姞鑷畾涔夊煙鍚?   - 鎸夋寚寮曢厤缃?DNS 璁板綍

---

## 鉁?鎺ㄨ崘閫夋嫨

| 骞冲彴 | 浼樼偣 | 闅惧害 |
|------|------|------|
| **Netlify** | 鏈€绠€鍗曪紝鎷栨嫿鍗冲彲 | 猸?|
| **Vercel** | 閫熷害蹇紝鑷姩鏇存柊 | 猸愨瓙 |
| **GitHub Pages** | 绋冲畾锛屼笌浠ｇ爜涓€璧风鐞?| 猸愨瓙 |
| **Cloudflare Pages** | 鍏ㄧ悆 CDN锛岄€熷害鏈€蹇?| 猸愨瓙 |

---

## 馃摫 閮ㄧ讲鍚庢祴璇?
閮ㄧ讲瀹屾垚鍚庯紝鍦ㄤ互涓嬪湴鏂规祴璇曡闂細

- 鉁?涓浗鍥藉唴
- 鉁?缇庡浗
- 鉁?娆ф床
- 鉁?涓滃崡浜?
浣跨敤宸ュ叿锛?- https://www.websitepulse.com/tools/webpage-test
- https://www.dotcom-tools.com/website-speed-test.aspx

---

## 馃帹 褰撳墠缃戠珯鏂囦欢浣嶇疆

```
C:\Users\huawei\.easyclaw\workspace\artist-website\
鈹溾攢鈹€ index.html      # 涓婚〉闈?鈹溾攢鈹€ styles.css      # 鏍峰紡
鈹溾攢鈹€ script.js       # 鑴氭湰
鈹溾攢鈹€ images/         # 鍥剧墖鏂囦欢澶?鈹?  鈹溾攢鈹€ observer-2025.jpg
鈹?  鈹溾攢鈹€ boundary-2022.jpg
鈹?  鈹溾攢鈹€ horse-2012.jpg
鈹?  鈹溾攢鈹€ subconscious-2014.jpg
鈹?  鈹斺攢鈹€ emotions-2019.jpg
鈹斺攢鈹€ README_deploy.md # 鏈儴缃叉寚鍗?```

---

## 馃挕 闇€瑕佸府鍔╋紵

鍛婅瘔鎴戜綘鎯崇敤鍝釜骞冲彴锛屾垜鍙互甯綘瀹屾垚鍏蜂綋姝ラ锛?